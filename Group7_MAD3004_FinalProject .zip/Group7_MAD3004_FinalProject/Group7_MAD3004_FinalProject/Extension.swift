//
//  Extension.swift
//  C0742318_MAD3004_FinalProject
//
//  Created by  Z Angrazy Jatt on 2018-09-20.
//  Copyright © 2018  Z Angrazy Jatt. All rights reserved.
//

import Foundation

extension Float
{
    func currency() -> String
    {
        return "$ \(self)"
    }
    
}

extension Double
{
    func Currency() -> String
    {
        return "$ \(self)"
    }
    
}

extension Int
{
    func currencyI() -> String
    {
        return "$ \(self)"
    }
    
}
